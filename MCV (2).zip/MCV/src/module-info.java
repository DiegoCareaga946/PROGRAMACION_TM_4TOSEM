/**
 * 
 */
/**
 * 
 */
module MCV {
	requires java.desktop;
	requires json.simple;
}