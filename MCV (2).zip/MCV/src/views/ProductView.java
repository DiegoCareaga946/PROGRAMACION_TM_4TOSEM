package views;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class ProductView {
    JFrame ventana;
    JPanel listaPanel;
    JTable tabla;
    
    ArrayList <Object> lista = new ArrayList <Object>();
    
    int x = 0;
    
    public void products(JSONArray data) {
        ventana = new JFrame("Productos");
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setSize(920, 534);
        
        // Panel principal con scroll
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        
       // JScrollPane scrollPane = new JScrollPane(mainPanel);
        //ventana.add(scrollPane);

        // Panel para los productos
        JPanel productsPanel = new JPanel();
        productsPanel.setLayout(new BorderLayout());
        
        // Título
        JLabel titulo = new JLabel("LISTA DE PRODUCTOS", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        productsPanel.add(titulo, BorderLayout.NORTH);
        
        // Panel para la lista de productos
        listaPanel = new JPanel();
        listaPanel.setLayout(new GridLayout(x,1,10,10));
        
        String[] tituloColumna = {"nombre", "id", "precio", "stock"};
        
        
        // Mostrar cada producto
        for (Object obj : data) {
            JSONObject product = (JSONObject) obj;
            
            Object[][] matriz;
            
            String nombre = (String) product.get("nombre");
            double precio = (double) product.get("precio");
            long id = (long) product.get("id");
            long stock = (long) product.get("stock");
            
            
            
           
            listaPanel.add(tabla);
        }
        
        productsPanel.add(listaPanel, BorderLayout.CENTER);
        mainPanel.add(productsPanel, BorderLayout.CENTER);
        ventana.setVisible(true);
    }
}