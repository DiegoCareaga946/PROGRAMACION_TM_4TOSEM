package models;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class ProductModel {
	
	  
    public ProductModel() {
    	
    }

    public JSONArray get() {
        JSONParser jsonParser = new JSONParser();
        String url = ProductModel.class.getResource("/Files/producto.json").getPath(); // Corregido: Usar ProductModel.class
        
        try (FileReader reader = new FileReader(url)) {
            // 1. Parsear el JSON como un objeto (porque empieza con {)
            JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);
            
            // 2. Obtener el array "productos" del objeto
            JSONArray productList = (JSONArray) jsonObject.get("productos");
            
            System.out.println(productList); // Opcional: Para depuración
            return productList;
            
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        
        return null; // En caso de error
    }
	
    private static void parseTestData(JSONObject product) {

        String nombre = (String) product.get("nombre");   
        System.out.println("Nombre: " + nombre);
        
        double precio = (double) product.get("precio");   
        System.out.println("Precio: " + precio);
          
        long id = (long) product.get("id"); 
        System.out.println("ID: " + id); 
        
        long stock = (long) product.get("stock");
        System.out.println("Stock: " + stock);
        
    }
    
}