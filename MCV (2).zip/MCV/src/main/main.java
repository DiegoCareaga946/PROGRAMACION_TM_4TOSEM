package main;

import controllers.AuthController;
import controllers.ProductController;

public class main {

	public static void main(String[] args) {
		ProductController application = new ProductController();
			application.products();
		}
	
	}